<?php declare(strict_types=1);

namespace Phan\PluginV2;

/**
 * @deprecated use PluginV3
 */
interface AutomaticFixCapability extends \Phan\PluginV3\AutomaticFixCapability
{
}
