<?php

use Test\CustomException;

class Class001
{
  /**
   * @throws CustomException exception
   */
  public function test()
  {
  }
}
