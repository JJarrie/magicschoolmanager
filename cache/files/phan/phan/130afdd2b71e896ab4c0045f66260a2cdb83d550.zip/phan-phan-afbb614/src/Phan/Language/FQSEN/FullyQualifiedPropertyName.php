<?php declare(strict_types=1);

namespace Phan\Language\FQSEN;

/**
 * A Fully-Qualified Property Name
 */
class FullyQualifiedPropertyName extends FullyQualifiedClassElement
{
}
