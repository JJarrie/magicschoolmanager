<?php

use Test\CustomException;

class Class000
{
}
