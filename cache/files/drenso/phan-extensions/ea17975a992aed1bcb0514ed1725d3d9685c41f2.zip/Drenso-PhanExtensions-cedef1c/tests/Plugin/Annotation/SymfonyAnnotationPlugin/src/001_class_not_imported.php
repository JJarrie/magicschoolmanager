<?php

/**
 * @Number1()
 * @Number2
 */
class Class001
{

}
