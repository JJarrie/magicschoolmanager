<?php
return [
    'directory_list' => [
        'src'
    ],
    'plugins' => [
        './../../../../Plugin/DocComment/MethodPlugin.php',
    ],
];
