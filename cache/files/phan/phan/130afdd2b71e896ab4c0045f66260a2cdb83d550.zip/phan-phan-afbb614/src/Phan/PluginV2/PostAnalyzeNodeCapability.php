<?php declare(strict_types=1);

namespace Phan\PluginV2;

/**
 * Use PluginV3
 * @deprecated
 */
interface PostAnalyzeNodeCapability extends \Phan\PluginV3\PostAnalyzeNodeCapability
{
}
