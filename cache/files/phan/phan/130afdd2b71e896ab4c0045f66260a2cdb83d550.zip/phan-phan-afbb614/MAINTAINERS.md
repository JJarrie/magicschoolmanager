Phan is maintained by the following people.

All maintainers must agree to the [Developer Certificate of Origin](https://github.com/phan/phan/blob/38bf1fd15e39bc668084accb8caab21f09ff75ba/DCO.txt).

# Maintainers

**Andrew S. Morrison**<br />
As a maintainer of Phan, I agree to the [Developer Certificate of Origin](https://github.com/phan/phan/blob/38bf1fd15e39bc668084accb8caab21f09ff75ba/DCO.txt).

**Rasmus Lerdorf**<br />
As a maintainer of Phan, I agree to the [Developer Certificate of Origin](https://github.com/phan/phan/blob/38bf1fd15e39bc668084accb8caab21f09ff75ba/DCO.txt).

**Tyson Andre**<br />
As a maintainer of Phan, I agree to the [Developer Certificate of Origin](https://github.com/phan/phan/blob/38bf1fd15e39bc668084accb8caab21f09ff75ba/DCO.txt).
