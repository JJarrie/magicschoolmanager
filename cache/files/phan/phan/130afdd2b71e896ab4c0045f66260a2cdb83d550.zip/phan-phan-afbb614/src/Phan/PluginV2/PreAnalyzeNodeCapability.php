<?php declare(strict_types=1);

namespace Phan\PluginV2;

/**
 * Use PluginV3
 * @deprecated
 */
interface PreAnalyzeNodeCapability extends \Phan\PluginV3\PreAnalyzeNodeCapability
{
}
