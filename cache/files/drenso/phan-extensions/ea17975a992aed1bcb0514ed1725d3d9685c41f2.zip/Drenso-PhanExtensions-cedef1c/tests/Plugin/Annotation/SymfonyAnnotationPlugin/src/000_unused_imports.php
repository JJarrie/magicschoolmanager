<?php

use Annotations\Number1;
use Annotations\Number2;

class Class000
{
}
