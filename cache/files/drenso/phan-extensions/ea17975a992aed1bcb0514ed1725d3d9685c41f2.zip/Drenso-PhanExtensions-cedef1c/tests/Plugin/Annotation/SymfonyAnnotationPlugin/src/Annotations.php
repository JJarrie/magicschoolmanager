<?php

namespace Annotations {
  class Number1
  {

  }

  class Number2
  {

  }
}
