<?php declare(strict_types=1);

namespace Phan\Plugin\Internal;

return new MethodSearcherPlugin();
