<?php

class Class003
{
  /**
   * @Number1()
   * @Number2
   */
  public function test()
  {

  }
}
