<?php

namespace MyOtherNS;

use Test\CustomException;

class Class002
{
  /**
   * @throws CustomException exception
   */
  public function test()
  {
  }
}
