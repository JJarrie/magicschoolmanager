<?php

use Annotations\Number1;
use Annotations\Number2;

class Class006
{

  /**
   * @Number1()
   * @Number2
   */
  public $x;
}
