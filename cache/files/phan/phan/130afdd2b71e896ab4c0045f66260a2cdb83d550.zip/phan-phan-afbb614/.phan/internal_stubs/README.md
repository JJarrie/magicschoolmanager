This folder will eventually contain stubs for the latest versions of various extensions.
If the extension is loaded in the binary to run phan, then phan will do nothing.
The plan is to make phan load these files and act as though internal classes, constants,
and functions existed with the same signatures as these php files.
