<?php

namespace MyOtherNS;

use ast\Node;

/**
 * @method Node retrieveNode()
 */
class Class002
{
}
