<?php

use Annotations\Number1;
use Annotations\Number2;

/**
 * @Number1()
 * @Number2
 */
class Class002
{

}
