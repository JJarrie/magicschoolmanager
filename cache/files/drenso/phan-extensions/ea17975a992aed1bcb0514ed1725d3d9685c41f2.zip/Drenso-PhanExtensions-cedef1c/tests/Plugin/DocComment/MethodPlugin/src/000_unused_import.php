<?php

use ast\Node;

class Class000
{
}
