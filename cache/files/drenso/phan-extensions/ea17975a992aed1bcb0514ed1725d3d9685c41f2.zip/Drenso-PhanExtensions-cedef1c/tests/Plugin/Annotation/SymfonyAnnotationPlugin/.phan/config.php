<?php
return [
    'directory_list' => [
        'src'
    ],
    'plugins' => [
        './../../../../Plugin/Annotation/SymfonyAnnotationPlugin.php',
    ],
];
