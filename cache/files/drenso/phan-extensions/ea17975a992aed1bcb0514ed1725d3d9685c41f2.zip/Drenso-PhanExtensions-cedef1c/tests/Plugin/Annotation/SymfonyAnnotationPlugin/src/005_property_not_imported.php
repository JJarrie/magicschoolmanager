<?php

class Class005
{

  /**
   * @Number1()
   * @Number2
   */
  public $x;
}
