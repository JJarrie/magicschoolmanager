<?php

namespace Test {
  class CustomException extends \Exception
  {

  }
}
