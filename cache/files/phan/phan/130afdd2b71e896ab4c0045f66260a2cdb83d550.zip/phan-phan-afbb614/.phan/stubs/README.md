Add any stubs to this directory for code that you don't want to parse, but still want
to expose to phan while analyzing the phan codebase
