<?php

use Annotations\Number1;
use Annotations\Number2;

class Class004
{
  /**
   * @Number1()
   * @Number2
   */
  public function test()
  {

  }
}
