<?php

use ast\Node;

/**
 * @method Node retrieveNode()
 */
class Class001
{
}
